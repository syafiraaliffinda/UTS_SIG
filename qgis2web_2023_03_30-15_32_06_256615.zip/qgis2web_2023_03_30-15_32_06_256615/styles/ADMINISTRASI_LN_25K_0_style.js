var size = 0;
var placement = 'point';
function categories_ADMINISTRASI_LN_25K_0(feature, value, size, resolution, labelText,
                       labelFont, labelFill, bufferColor, bufferWidth,
                       placement) {
                switch(value.toString()) {case 'ampungkelor - Pondokkelor':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(195,124,221,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'ampungkelor - Teluknaga':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(196,122,207,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Ancolpasir - Pasirbarat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(45,200,17,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Ancolpasir - Rancabuaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(107,209,189,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Ancolpasir - Taban':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(56,227,156,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Babakan - Batok':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(84,49,226,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Babakan - Kemuning':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(97,230,44,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Babakan - Legok':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(203,125,37,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Babakanasem - Kampungmelayu Timur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,21,196,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Babakanasem - Teluknaga':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(214,84,199,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Babat - Bojongkamal':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(95,186,211,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Babat - Ciangir':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(226,129,132,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Babat - Palasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(37,116,220,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Badakanom - Sindangsono':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(46,198,218,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bakung - Blubuk':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(69,214,178,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bakung - Pagedangan Udik':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(166,29,212,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bakung - Pagenjahan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(42,211,84,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bakung - Pasilian':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(221,139,112,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bakung - Pasir':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(213,18,122,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Balaraja - Cikupa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(205,109,24,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Balaraja - Jayanti':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(180,118,230,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Balaraja - Saga':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(151,32,206,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Balaraja - Sentuljaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(46,215,27,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Balaraja - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(38,227,54,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Balaraja - Talagasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(211,167,63,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Balaraja - Tigaraksa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(238,138,77,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Balaraja - Tobat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(28,231,174,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bantarpanjang - Cileles':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(87,209,35,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bantarpanjang - Sodong':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(217,13,98,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bantarpanjang - Tapos':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(58,232,206,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Banten - DKI Jakarta':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(170,119,228,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Banten - Jawa Barat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(214,115,125,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Banyuasih - Ketapang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(69,221,238,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Banyuasih - Margamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(239,74,124,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Banyuasih - Tegalkunir Kidul':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(233,132,215,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Banyuasih - Tegalkunir Lor':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(79,21,204,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Batuceper - Periuk':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(236,157,130,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Belimbing - Jatimulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(65,239,17,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Belimbing - Kosambi Timur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(234,186,109,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Belimbing - Rawaburung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(232,67,166,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Belimbing - Salembaranjati':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(192,122,230,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Belimbing - Salembaranjaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(206,44,46,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bencongan - Cibodasbaru':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(29,121,240,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bencongan Indah - Binong':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(77,213,179,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bencongan Indah - Bojongnangka':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(35,201,13,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bencongan Indah - Kelapadua':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(100,209,167,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bencongan Indah - Sukabakti':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(125,213,233,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Benda - Bunar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,22,159,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Benda - Buniayu':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(213,102,207,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Benda - Kaliasin':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(55,72,222,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Benda - Merak':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(126,240,202,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bendung - Sukamanah':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(75,173,211,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Binong - Kadu':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(197,122,227,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Binong - Sukabakti':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(204,217,89,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Binuang - Cakung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(218,187,30,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Binuang - Carenang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(181,227,102,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Binuang - Cikande':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,85,60,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bitungjaya - Bunder':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(212,107,132,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bitungjaya - Dukuh':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(102,185,206,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bitungjaya - Pasirgadung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(185,209,111,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bitungjaya - Sukadamai':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(217,114,89,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Blubuk - Pagenjahan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(153,200,103,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojong - Budimulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(210,106,132,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojong - Cibadak':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(162,79,226,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojong - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(163,214,91,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojong - Sukanagara':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(56,233,106,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojong - Talaga':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(62,207,32,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongkamal - Cirarab':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(204,58,114,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongkamal - Palasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(211,55,70,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongloa - Carenang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(206,67,67,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongloa - Caringin':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(76,41,216,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongloa - Cempaka':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(52,39,238,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongloa - Cibugel':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(73,220,127,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongloa - Cisoka':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(240,44,191,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongloa - Karangharja':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(90,220,118,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongnangka - Curug Wetan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(115,126,212,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongnangka - Curugsangerang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(221,240,15,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongnangka - Kelapadua':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(205,31,147,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongnangka - Sukabakti':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(240,136,230,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bojongrenged - Teluknaga':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(206,118,224,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bonisari - Buaranbambu':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(135,229,67,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bonisari - Kayuagung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(131,125,240,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bonisari - Pakuhaji':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(69,143,208,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bonisari - Rawaboni':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(87,203,207,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranbambu - Kramat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(203,216,21,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranbambu - Laksana':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(211,194,42,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranbambu - Pakualam':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(131,202,224,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranbambu - Pakuhaji':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(222,32,118,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranbambu - Rawaboni':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(113,45,221,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranjati - Gintung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(18,79,236,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranjati - Pekayon':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(226,42,174,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranjati - Rawakidang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(237,99,94,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranmangga - Kramat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(161,35,234,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranmangga - Pakualam':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(205,218,122,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranmangga - Pakuhaji':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(171,117,200,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranmangga - Sukawali':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(115,209,34,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Buaranmangga - Suryabahari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(226,145,83,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Budimulya - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(28,228,18,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bunar - Merak':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(240,87,181,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bunder - Pasirjaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(120,162,214,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Bunder - Sukadamai':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(94,35,230,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cangkudu - Gembong':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(207,22,201,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cangkudu - Sentul':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(190,226,58,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cangkudu - Sukamurni':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(103,208,154,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Carenang - Cempaka':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(217,132,87,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Carenang - Karangharja':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(219,133,212,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Carenangudik - Nyompok':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(140,61,224,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Caringin - Cibugel':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(40,215,110,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Caringin - Cirarab':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(152,200,113,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Caringin - Cisoka':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(201,128,86,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Caringin - Jengjing':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(235,71,238,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Caringin - Kemuning':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(85,150,220,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Caringin - Palasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(130,151,219,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Caringin - Selapajang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(134,101,223,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cempaka - Cisoka':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(77,221,42,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cempaka - Karangharja':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(205,117,201,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cempaka - Sukatani':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(99,161,211,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Ciakar - Mekarbakti':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(151,235,48,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Ciakar - Panongan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(97,219,209,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cibadak - Sukanagara':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(215,142,109,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cibadak - Talaga':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(195,78,213,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cibetok - Cipaeh':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(235,219,138,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cibetok - Kandawati':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(111,53,226,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cibetok - Racagede':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(122,229,135,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cibetok - Tamiang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(207,49,154,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cibogo - Cisauk':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(41,38,236,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cibogo - Sampora':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(49,151,206,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cibogo - Suradita':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(40,213,40,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cibugel - Selapajang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(106,207,188,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cicalengka - Cijantra':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(174,23,201,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cicalengka - Kadusirung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(100,219,149,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cicalengka - Lengkong Kulon':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(77,212,233,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cicalengka - Pagedangan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(95,218,18,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cicalengka - Situgadung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(71,166,225,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cidahu - Rancasumur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(202,92,84,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cihuni - Lengkong Kulon':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(23,231,96,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cihuni - Medang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(205,231,59,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cijantra - Lengkong Kulon':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(185,223,16,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cijantra - Medang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(114,210,135,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cijeruk - Jenggot':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(179,96,235,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cijeruk - Kedaung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(202,93,200,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cijeruk - Mekarbaru':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(113,129,229,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cijeruk - Waliwis':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(67,227,23,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikande - Jayanti':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,65,74,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikande - Pangkat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(222,23,56,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikande - Parigi':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(200,95,161,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikande - Pasirgintung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(228,198,123,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikande - Sumurbandung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(47,116,236,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikareo - Cikuya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(215,146,41,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikareo - Cireundeu':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(224,171,96,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikareo - Pasanggrahan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(204,106,224,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikareo - Solear':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(63,74,202,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikasungka - Cikuya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(37,216,150,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikupa - Dukuh':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(169,33,237,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikupa - Panongan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(127,46,208,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikupa - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(215,166,114,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikupa - Talagasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(202,120,122,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikuya - Cireundeu':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(94,217,117,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cikuya - Solear':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,14,122,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cilenggang - Lengkonggudang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(118,225,166,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cipaeh - Gunungkaler':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(210,118,90,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cipaeh - Kandawati':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(225,40,235,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cipaeh - Kedung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(68,75,204,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cipaeh - Onyam':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(19,105,234,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cipaeh - Racagede':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(119,16,216,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cipaeh - Sidoko':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(114,220,72,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cireundeu - Solear':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(163,239,93,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cirumpak - Pagedangan Udik':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(79,222,127,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cirumpak - Pasir':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(222,79,151,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cisauk - Dangdang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(219,235,45,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cisauk - Pagedangan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(215,105,62,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cisauk - Sampora':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(203,112,236,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cisauk - Suradita':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(140,231,141,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cisereh - Pasirbolang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(145,236,80,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cisereh - Pematang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(185,206,29,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cisoka - Balaraja':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(133,234,143,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cisoka - Jengjing':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(95,208,214,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cisoka - Sukatani':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(156,228,23,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cukanggalih - Curug Kulon':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(61,235,160,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cukanggalih - Kadujaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(177,132,232,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Cukanggalih - Sukabakti':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(214,100,113,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Curug - Cikupa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(116,226,228,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Curug - Panongan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(83,112,229,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Curug Kulon - Curug Wetan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(231,22,175,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Curug Kulon - Sukabakti':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(208,228,117,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Curug Wetan - Sukabakti':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(235,182,116,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Curugsangerang - Kelapadua':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(68,213,165,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Curugsangerang - Pakulonan Barat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(15,148,236,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Dadap - Kosambi Timur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(208,121,211,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Dangdang - Mekarwangi':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(43,199,238,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Dangdang - Suradita':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(195,203,33,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Dangdeur - Pabuaran':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(123,202,208,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Dangdeur - Pangkat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(165,215,116,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Dangdeur - Sumurbandung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(35,232,176,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Daon - Jambukarya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(229,157,13,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Daon - Sukamanah':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(174,212,70,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Daon - Sukatani':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(225,185,55,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Daru - Mekarsari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(200,67,120,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Daru - Sukamanah':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(96,66,204,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Daru - Taban':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(212,64,226,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Daru - Tiparraya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(130,146,231,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Dukuh - Pasirgadung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(237,108,209,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Dukuh - Talagasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(125,235,62,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gaga - Kiarapayung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(218,105,30,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gandaria - Kosambi Dalam':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(137,108,225,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gebangraya - Gembor':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,137,167,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gelamjaya - Kotabumi':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,167,89,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gelamjaya - Kutabaru':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(231,109,164,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gelamjaya - Kutajaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(59,56,234,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gembong - Sukamurni':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(219,203,57,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gempolsari - ampungkelor':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(200,156,60,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gempolsari - Jatimulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(215,78,63,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gempolsari - Kedaung Barat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(211,50,222,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gempolsari - Pondokkelor':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(98,235,35,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gempolsari - Sangiang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(215,67,217,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gintung - Kosambi':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(50,235,161,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gintung - Rawakidang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(148,111,215,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gunung Kaler - Kronjo':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(220,136,66,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gunung Kaler - Mekarbaru':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(81,103,214,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gunungkaler - Kedung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(102,217,202,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gunungkaler - Onyam':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(110,71,240,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gunungsari - Mauk Barat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(150,230,97,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gunungsari - Mauk Timur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(210,199,74,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Gunungsari - Sasak':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(95,97,202,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jambe - Kutruk':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(35,191,218,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jambe - Legok':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(183,209,97,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jambe - Tiparraya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(239,116,133,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jambukarya - Sukamanah':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(71,235,235,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jatake - Kadusirung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(121,123,224,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jatake - Karangtengah':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,88,114,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jatake - Malangnengah':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(240,35,103,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jatake - Pasirjaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(104,239,239,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jatimulya - Dadap':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(221,102,205,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jatimulya - Kedaung Barat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(99,166,200,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jatimulya - Kosambi Timur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(100,200,115,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jatimulya - Sangiang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(166,217,37,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jatimulya - Tanahmerah':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(132,234,180,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jatiwaringin - Kedungdalem':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(81,207,129,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jatiwaringin - Tegalkunir Kidul':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(215,131,155,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jayanti - Cisoka':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(59,53,219,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jayanti - Kresek':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(205,132,83,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jayanti - Pasirmuncang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(90,234,68,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jayanti - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(65,239,49,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jayanti - Sumurbandung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(47,227,155,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jenggot - Kedaung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(201,61,175,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jenggot - Waliwis':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(214,186,102,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jengkol - Kemuning':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(67,208,102,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jengkol - Patrasana':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(223,130,31,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jengkol - Renged':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(70,203,61,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Jengkol - Talok':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(202,193,28,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kadu - Kadujaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(62,218,202,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kadu - Sukabakti':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(173,232,126,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kaduagung - Margasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(202,176,71,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kaduagung - Peusar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(94,138,225,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kaduagung - Sodong':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(61,15,213,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kaduagung - Tigaraksa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(89,231,219,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kadujaya - Sukabakti':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(84,215,176,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kadusirung - Situgadung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(238,51,170,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kaliasin - Merak':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(201,162,54,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kaliasin - Parahu':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(200,86,68,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kaliasin - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(121,213,170,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kampungmelayu Barat - Kampungbesar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(13,209,124,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kampungmelayu Barat - Kampungmelayu Timur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(236,178,71,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kampungmelayu Barat - Teluknaga':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(104,235,165,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kampungmelayu Timur - Kampungbesar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(31,71,218,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kandawati - Onyam':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(63,203,12,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Karanganyar - Kemiri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(94,215,234,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Karanganyar - Klebet':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(85,227,38,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Karanganyar - Lontar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,140,115,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Karanganyar - Patramanggala':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(25,208,83,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Karangserang - Pekayon':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(151,115,215,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Karangserang - Sukadiri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(105,132,215,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Karangtengah - Malangnengah':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(26,209,57,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Karet - Mekarjaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(62,121,216,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Karet - Sepatan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(88,224,236,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kayuagung - Kayubongkok':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(203,53,203,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kayuagung - Sarakan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(202,58,108,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kayubongkok - Pisanganjaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(199,37,217,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kayubongkok - Sarakan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(103,56,223,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Keboncau - Babakanasem':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(94,178,211,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Keboncau - Teluknaga':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(172,120,209,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kedaung Barat - ampungkelor':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(208,71,80,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kedaung Barat - Lebakwangi':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(233,116,134,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kedaung Wetan - Kedaungbaru':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(225,228,64,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kedung - Sidoko':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(42,224,160,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kedungdalem - Sasak':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(206,204,90,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kedungdalem - Tegalkunir Kidul':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(213,48,106,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kelapadua - Pakulonan Barat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(59,223,40,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kemiri - Klebet':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(220,68,48,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kemiri - Kronjo':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(236,160,127,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kemiri - Mauk':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(15,235,132,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kemiri - Patramanggala':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(229,136,162,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kemiri - Rancalabuh':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(133,25,210,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kemiri - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(191,224,102,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kemuning - Legok':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(69,224,196,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kemuning - Palasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(200,160,28,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kemuning - Rancagong':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(101,228,72,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kemuning - Rancailat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(160,211,121,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kemuning - Serdang Wetan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,15,63,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kemuning - Talok':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(163,227,52,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Ketapang - Margamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(117,106,204,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Ketapang - Mauk Barat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(65,201,185,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Ketapang - Mauk Timur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(104,225,181,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Ketapang - Tegalkunir Lor':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(224,16,26,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Klebet - Legoksukamaju':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(102,187,216,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Klebet - Lontar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(225,99,158,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Klebet - Rancalabuh':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(104,215,237,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Klutuk - Kosambi Dalam':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(108,223,112,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Klutuk - Mekarbaru':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(113,211,127,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Klutuk - Waliwis':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(196,212,119,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Koper - Pasirampo':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(208,99,170,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Koper - Songgomjaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(75,203,37,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kosambi - Mekarkondang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(220,153,36,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kosambi - Rawakidang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(200,12,71,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kosambi Dalam - Mekarbaru':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(89,215,97,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kosambi Dalam - Pagenjahan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(238,220,116,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kosambi Timur - Kosambi Barat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(154,206,94,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kota Jakarta Utara - Kota Jakarta Barat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(187,110,220,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kotabumi - Kutabaru':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(149,239,128,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kotabumi - Kutajaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(231,163,100,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kotabumi - Pangadegan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(214,211,17,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kotabumi - Sukamantri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(215,203,32,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kramat - Gaga':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(17,137,202,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kramat - Kiarapayung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(162,225,37,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kramat - Laksana':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(167,110,203,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kramat - Pakualam':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(236,122,190,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kramat - Sukawali':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(46,150,225,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kresek - Gunung Kaler':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(134,60,238,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kresek - Kronjo':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(160,228,123,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kresek - Renged':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(195,111,231,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kresek - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(201,75,47,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kresek - Talok':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(48,138,223,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kronjo - Mekarbaru':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(202,196,108,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kronjo - Muncung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(160,211,93,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kronjo - Pagedangan Ilir':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(77,85,206,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kronjo - Pagedangan Udik':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(133,99,224,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kronjo - Pasilian':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(19,236,95,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kronjo - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(130,113,240,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kubang - Parahu':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(118,128,240,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kubang - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(30,162,210,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kutajaya - Sukamantri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(121,131,210,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kutruk - Pasirbarat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(219,60,24,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Kutruk - Rancabuaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(115,164,203,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Laksana - Kiarapayung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(106,167,213,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Lebak - Tangerang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(179,90,204,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Legok - Medang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(144,200,60,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Legok - Panongan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(89,202,196,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Legok - Rancagong':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(214,39,233,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Legoksukamaju - Rancalabuh':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(53,191,201,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Lembangsari - Rajeg':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(201,131,81,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Lembangsari - Rajegmulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(200,129,115,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Lembangsari - Rancabango':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(122,186,213,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Lembangsari - Tanjakan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(59,223,220,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Lemo - Kampungbesar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(192,135,227,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Lengkong Karya - Lengkong Wetan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(26,17,203,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Lengkong Kulon - Medang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(221,238,91,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Lengkong Kulon - Pagedangan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(203,41,171,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Margamulya - Tanjunganom':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(13,228,214,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Margasari - Sodong':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(132,223,161,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mauk - Sukadiri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(117,216,213,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mauk Barat - Mauk Timur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(124,222,124,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mauk Timur - Sasak':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(217,142,66,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mauk Timur - Tegalkunir Lor':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(180,204,85,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarbakti - Panongan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(113,205,118,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarbakti - Peusar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(210,107,224,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarbaru - Kronjo':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(38,218,128,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarbaru - Rancasumur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(78,236,146,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarbaru - Waliwis':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(81,183,230,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarjaya - Rancaiyuh':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(62,218,140,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarjaya - Sepatan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(143,213,51,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarjaya - Serdangkulon':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(45,112,206,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarkondang - Rawakidang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(35,226,194,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarsari - Rajeg':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(70,113,230,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarsari - Rajegmulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(38,38,205,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarsari - Rancabango':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(68,215,110,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarsari - Sukamanah':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(136,182,229,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarsari - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(111,201,182,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarsari - Sukasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(54,128,207,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Mekarsari - Sukatani':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(116,34,239,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Merak - Parahu':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(153,228,40,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Muara - Lemo':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(190,108,210,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Muara - Tanjungpasir':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(235,220,124,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Munjul - Pasanggrahan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(119,29,202,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pagedangan - Curug':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(59,201,230,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pagedangan - Legok':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(133,237,125,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pagedangan - Situgadung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(231,145,114,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pagedangan Ilir - Pagedangan Udik':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(224,57,79,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pagedangan Udik - Pasilian':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(121,54,207,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pagedangan Udik - Pasir':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(165,216,108,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pagenjahan - Pasilian':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(203,98,211,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pajang - Benda':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(238,231,28,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pakualam - Pakuhaji':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,215,100,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pakuhaji - Sukadiri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(219,158,78,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pakulonan - Pakulonan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(171,218,60,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Palasari - Serdang Wetan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(94,223,13,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pangadegan - Sindangsari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,102,211,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pangadegan - Sukamantri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(108,226,169,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pangkalan - Kampungbesar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(206,59,174,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pangkalan - Kampungmelayu Barat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(124,178,209,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pangkalan - Tanjungburung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(226,64,207,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pangkalan - Tanjungpasir':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(204,68,181,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pangkalan - Tegalangus':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(29,129,222,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pangkat - Pasirgintung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(217,77,114,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pangkat - Sumurbandung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(211,190,104,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Panongan - Jambe':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(200,237,125,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Panongan - Peusar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(85,204,107,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Panongan - Rancakalapa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(215,202,115,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Panongan - Serdangkulon':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(208,42,156,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Panongan - Tigaraksa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(56,109,201,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Parahu - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(153,111,237,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasanggrahan - Solear':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(229,112,57,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasarkemis - Cikupa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(143,235,155,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasarkemis - Sepatan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(151,231,23,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasarkemis - Sindangjaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(21,220,80,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasarkemis - Sindangsari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(95,101,230,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasarkemis - Sukaasih':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(46,206,115,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasarkemis - Sukamantri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(38,117,207,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasirampo - Patrasana':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(195,200,38,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasirbarat - Rancabuaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(157,222,16,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasirbolang - Pasirnangka':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(220,137,22,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasirbolang - Pematang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(170,125,206,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasirgadung - Pasirjaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(25,235,186,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasirgadung - Sukadamai':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(72,107,222,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasirgadung - Talagasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(232,74,163,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasirjaya - Sukadamai':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(191,216,47,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasirmuncang - Sumurbandung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(224,127,164,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasirnangka - Pematang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(147,98,233,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasirnangka - Peusar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(227,197,116,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pasirnangka - Tigaraksa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(231,234,74,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Patrasana - Renged':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(204,157,122,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pekayon - Rawakidang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(161,225,130,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pekayon - Sukadiri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(238,144,183,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pematang - Pete':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(180,62,209,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pematang - Tegalsari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(232,96,96,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pematang - Tigaraksa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(72,41,224,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pete - Tegalsari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(81,130,236,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pete - Tigaraksa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,85,167,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Peusar - Tigaraksa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(82,53,223,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pisanganjaya - Sarakan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(46,17,211,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pisanganjaya - Sepatan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(195,88,219,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Pondokjaya - Sepatan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(219,165,100,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Racagede - Sidoko':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(150,97,215,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Racagede - Tamiang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(55,78,207,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rajeg - Kemiri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(228,83,70,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rajeg - Mauk':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(109,112,204,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rajeg - Pasarkemis':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(92,35,226,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rajeg - Rajegmulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(223,90,66,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rajeg - Rancabango':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(98,219,130,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rajeg - Sepatan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(26,65,225,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rajeg - Sindangjaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(39,17,240,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rajeg - Sukadiri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(29,214,41,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rajegmulya - Sukasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(215,23,61,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rajegmulya - Tanjakan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(55,228,150,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rajegmulya - Tanjakanmekar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,21,17,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rancabango - Sukamanah':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(225,193,118,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rancabango - Sukatani':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(235,82,115,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rancabuaya - Taban':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(111,206,148,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rancabuaya - Tiparraya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(223,121,214,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rancagong - Serdang Wetan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(216,140,18,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rancaiyuh - Rancakalapa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(210,76,170,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rancaiyuh - Serdangkulon':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,58,204,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rancakalapa - Serdangkulon':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(176,79,205,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rawaboni - Kiarapayung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(122,234,144,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rawaboni - Laksana':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(202,81,145,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rawakidang - Sukadiri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(45,144,214,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Rawarengas - Rawaburung':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(56,86,220,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Renged - Talok':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(208,111,63,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Saga - Talagasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,55,81,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Saga - Tobat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(132,225,88,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Salembaranjati - Kosambi Barat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(145,137,232,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Salembaranjati - Kosambi Timur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(190,77,225,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Salembaranjaya - Kosambi Barat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(213,13,50,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Salembaranjaya - Salembaranjati':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(31,94,240,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sangiang - Tanahmerah':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(135,206,124,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sarakan - Sepatan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(203,117,177,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sasak - Tegalkunir Kidul':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(110,82,231,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sasak - Tegalkunir Lor':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(203,185,121,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sentul - Sentuljaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(131,219,42,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sentul - Sukamurni':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(91,142,218,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sentul - Talagasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(15,200,178,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sentuljaya - Sukamurni':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(130,161,225,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sentuljaya - Talagasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(100,202,97,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sentuljaya - Tobat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(217,116,153,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sepatan Timur - Sepatan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(171,221,55,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Serang - Lebak':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(68,206,185,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Serang - Tangerang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(238,127,212,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Serpong - Serpong Utara':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(50,105,235,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sindangasih - Sindangjaya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(203,23,122,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sindangasih - Sindangsono':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(57,229,192,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sindangasih - Wanakerta':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(223,227,138,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sindangjaya - Balaraja':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(103,204,235,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sindangjaya - Cikupa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(95,208,212,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sindangjaya - Kemiri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(127,73,201,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sindangjaya - Sindangpanon':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(128,24,239,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sindangjaya - Sukamulya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(95,211,180,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sindangjaya - Wanakerta':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(58,218,95,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sindangpanon - Sukaharja':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(219,53,150,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sindangsono - Wanakerta':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(95,202,38,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sodong - Tapos':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(134,39,217,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sodong - Tigaraksa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(231,131,126,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Solear - Cisoka':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(121,234,84,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sukaasih - Sukamantri':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(92,70,235,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sukaharja - Wanakerta':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(220,57,35,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sukamanah - Taban':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(87,230,92,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sukamanah - Tanara':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(66,119,218,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sukamulya - Talaga':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(129,217,189,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sukamurni - Tobat':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(104,179,213,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sukanagara - Talaga':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(112,234,228,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Sukawali - Suryabahari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(237,83,22,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Taban - Tiparraya':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(226,29,22,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Talaga - Talagasari':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(113,218,123,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tangerang - Kota Tangerang':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(237,86,159,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tangerang - Kota Tangerang Selatan':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(86,213,84,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tanjakan - Tanjakanmekar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(234,146,139,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tanjungburung - Tanjungpasir':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(35,153,227,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tegalangus - Kampungbesar':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(104,207,101,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tegalangus - Lemo':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(213,17,102,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tegalangus - Muara':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(203,236,81,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tegalangus - Tanjungpasir':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(231,88,49,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tegalkunir Kidul - Tegalkunir Lor':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(237,237,107,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Teluknaga - Kampungmelayu Timur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(222,54,68,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Teluknaga - Kosambi':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(238,19,132,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Teluknaga - Sepatan Timur':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(223,26,220,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tigaraksa - Cikupa':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(50,91,204,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tigaraksa - Cisoka':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(237,215,114,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tigaraksa - Jambe':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(17,209,230,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Tigaraksa - Solear':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,113,61,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
default:
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(56,42,204,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;}};

var style_ADMINISTRASI_LN_25K_0 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = feature.get("NAMOBJ");
    var labelText = "";
    size = 0;
    var labelFont = "10px, sans-serif";
    var labelFill = "#000000";
    var bufferColor = "";
    var bufferWidth = 0;
    var textAlign = "left";
    var offsetX = 8;
    var offsetY = 3;
    var placement = 'line';
    if ("" !== null) {
        labelText = String("");
    }
    
var style = categories_ADMINISTRASI_LN_25K_0(feature, value, size, resolution, labelText,
                          labelFont, labelFill, bufferColor,
                          bufferWidth, placement);

    return style;
};
